=== Nextmind Theme Addons ===
Contributors: awaikentechnology
Tags: nextmind
Requires at least: 6.3
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GNU General Public License v3 or later.
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This plugin is intended for use with the nextmind theme.

== Description ==
This plugin is intended for use with the nextmind theme.

== Changelog ==

= 1.0.0  =
* Initial Release
